package kh.sellermoon.member.vo;

public class PaymentVO {
	String ORDER_NO       ="";      
	int  MEMBER_NO        =0;       
	String  CART_NO       ="";      
	int  ORDER_PAYMENT    =0;       
	int  ORDER_DATE       =0;       
	int  ORDER_AMOUNT     =0;       
	int  ORDER_USED_POINT =0;  
	String  PURCHASE_NO       ="";   
	String  PURCHASE_METHOD       ="";   
	String ORDER_DE_NO        ="";
	int ORDER_DE_QUANTITY =0; 
	int ORDER_DE_PRICE    =0; 
	String  ORDER_DE_CANCEL   ="";
	String  DELIVERY_STATUS   ="";
	
}
