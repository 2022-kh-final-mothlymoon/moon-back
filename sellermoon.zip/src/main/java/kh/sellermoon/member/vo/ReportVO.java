package kh.sellermoon.member.vo;

public class ReportVO {

}
