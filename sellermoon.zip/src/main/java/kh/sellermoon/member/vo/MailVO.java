package kh.sellermoon.member.vo;

import lombok.Data;

@Data
public class MailVO {
	private String address ="";
	private String title ="";
	private String message ="";
}
