package kh.sellermoon.member.vo;

public class MemoVO {

}
