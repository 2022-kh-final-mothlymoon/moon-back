package kh.sellermoon.member.dao;

import org.springframework.stereotype.Service;


@Service
public class KaKaoLoginDao {
	
	

}
