package kh.sellermoon.admin.vo;

import lombok.Data;

@Data
public class AdminVO {
	
	private String admin_id      = "";
	private String admin_pw      = "";
	private String admin_name    = "";
	private String admin_tel     = "";

}
